//package com.ctre.phoenix.Mechanical;
//
//import com.ctre.phoenix.MotorControl.*;
//
//public class Gearbox extends Linkage
//{
//	public Gearbox(IMotorController mc1)
//	{
//		super(mc1);
//	}
//	public Gearbox(IMotorController mc1, IMotorController mc2)
//	{
//		super(mc1, mc2);
//	}
//	public Gearbox(IMotorController mc1, IMotorController mc2, IMotorController mc3)
//	{
//		super(mc1, mc2, mc3);
//	}
//	public Gearbox(IMotorController mc1, IMotorController mc2, IMotorController mc3, IMotorController mc4)
//	{
//		super(mc1, mc2, mc3, mc4);
//	}
//}