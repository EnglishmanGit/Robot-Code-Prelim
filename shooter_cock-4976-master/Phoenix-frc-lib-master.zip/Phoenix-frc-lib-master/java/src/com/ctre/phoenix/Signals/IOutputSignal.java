package com.ctre.phoenix.Signals;

public interface IOutputSignal
{
	//void set(double value);
}