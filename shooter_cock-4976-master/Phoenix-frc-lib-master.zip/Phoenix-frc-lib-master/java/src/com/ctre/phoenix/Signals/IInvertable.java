package com.ctre.phoenix.Signals;

public interface IInvertable
{
	void setInverted(boolean invert);
	boolean getInverted();
}