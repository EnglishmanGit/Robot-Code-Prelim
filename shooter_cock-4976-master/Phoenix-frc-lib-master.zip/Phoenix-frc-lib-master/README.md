# Phoenix-frc-lib
CTRE Phoenix Application-Level Library for FRC Java and C++

Relevant Source Files are located in the following locations:

C++: cpp/include or cpp/source
Java: java/src/com/ctre

CTRE_PhoenixCCI libraries are located within the 'libraries' folder.
Build the gradle project located in CTRE_PhoenixCCI to update this binaries.

## Dependencies
FRC C++ Toolchain

Java Development Kit 8u77 (Any other version risks gradle incompatibility)
