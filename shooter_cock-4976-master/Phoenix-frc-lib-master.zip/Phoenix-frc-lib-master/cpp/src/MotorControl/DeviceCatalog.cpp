#include <ctre/phoenix/MotorControl/DeviceCatalog.h>

using namespace CTRE::MotorControl;

DeviceCatalog * DeviceCatalog::_instance = 0;
